$(function () {

    $("#department_id").on('change', function (e) {
        e.preventDefault();
        var Selector = '#promotionFilter';
        var department_id = $(this).val();
        var classID = "";
        classAllocation(department_id, Selector, classID);
    });
    $("#promote_department_id").on('change', function (e) {
        e.preventDefault();
        var Selector = '#promoteStudentForm';
        var department_id = $(this).val();
        var classID = "";
        $(Selector).find('select[name="promote_class_id"]').empty();
        $(Selector).find('select[name="promote_class_id"]').append('<option value="">' + select_grade + '</option>');
        if (department_id) {
            $.post(getGradeByDepartmentUrl,
                {
                    branch_id: branchID,
                    department_id: department_id
                }, function (res) {
                    if (res.code == 200) {
                        $.each(res.data, function (key, val) {
                            $(Selector).find('select[name="promote_class_id"]').append('<option value="' + val.id + '">' + val.name + '</option>');
                        });
                        if (classID != '') {
                            $(Selector).find('select[name="promote_class_id"]').val(classID);
                        }
                    }
                }, 'json');
        }
    });

    function classAllocation(department_id, Selector, classID) {
        $(Selector).find('select[name="class_id"]').empty();
        $(Selector).find('select[name="class_id"]').append('<option value="">' + select_grade + '</option>');
        $(Selector).find('select[name="section_id"]').empty();
        $(Selector).find('select[name="section_id"]').append('<option value="">' + select_class + '</option>');
        if (department_id) {
            $.post(getGradeByDepartmentUrl,
                {
                    branch_id: branchID,
                    department_id: department_id
                }, function (res) {
                    if (res.code == 200) {
                        $.each(res.data, function (key, val) {
                            $(Selector).find('select[name="class_id"]').append('<option value="' + val.id + '">' + val.name + '</option>');
                        });
                        if (classID != '') {
                            $(Selector).find('select[name="class_id"]').val(classID);
                        }
                    }
                }, 'json');
        }
    }

    $('#selectAllchkbox').prop('checked', false); // Unchecks it
    // script for all checkbox checked / unchecked
    $("#selectAllchkbox").on("change", function (ev) {
        var $chcks = $(".checked-area input[type='checkbox']");
        if ($(this).is(':checked')) {
            $chcks.prop('checked', true).trigger('change');
        } else {
            $chcks.prop('checked', false).trigger('change');
        }
    });
    // change 
    $('#changeClassName').on('change', function () {
        var class_id = $(this).val();
        $("#promotionFilter").find("#sectionID").empty();
        $("#promotionFilter").find("#sectionID").append('<option value="">' + select_class + '</option>');
        $.post(teacherSectionUrl, { token: token, branch_id: branchID, teacher_id: ref_user_id, class_id: class_id }, function (res) {
            if (res.code == 200) {
                $.each(res.data, function (key, val) {
                    $("#promotionFilter").find("#sectionID").append('<option value="' + val.section_id + '">' + val.section_name + '</option>');
                });
            }
        }, 'json');
    });
    // change 
    $('#promoteClassID').on('change', function () {
        var class_id = $(this).val();
        $("#promoteStudentForm").find(".promoteSectionID").empty();
        $("#promoteStudentForm").find(".promoteSectionID").append('<option value="">' + select_class + '</option>');
        $.post(teacherSectionUrl, { token: token, branch_id: branchID, teacher_id: ref_user_id, class_id: class_id }, function (res) {
            if (res.code == 200) {
                $.each(res.data, function (key, val) {
                    $("#promoteStudentForm").find(".promoteSectionID").append('<option value="' + val.section_id + '">' + val.section_name + '</option>');
                });
            }
        }, 'json');
    });
    // rules validation
    $("#promotionFilter").validate({
        rules: {
            year: "required",
            department_id: "required",
            class_id: "required",
            section_id: "required",
            session_id: "required",
            semester_id: "required"
        }
    });
    $('#promotionFilter').on('submit', function (e) {
        e.preventDefault();
        var form = this;
        var promValid = $("#promotionFilter").valid();
        if (promValid === true) {

            var department_id = $("#department_id").val();
            var class_id = $("#changeClassName").val();
            var section_id = $("#sectionID").val();
            var semester_id = $("#semester_id").val();
            var session_id = $("#session_id").val();
            var btwyears = $("#btwyears").val();
            var formData = new FormData();
            formData.append('token', token);
            formData.append('branch_id', branchID);
            formData.append('class_id', class_id);
            formData.append('section_id', section_id);
            formData.append('semester_id', semester_id);
            formData.append('session_id', session_id);
            formData.append('academic_session_id', btwyears);
            var classObj = {
                department_id: department_id,
                class_id: class_id,
                section_id: section_id,
                semester_id: semester_id,
                session_id: session_id,
                year: btwyears,
                academic_session_id: academic_session_id
            };
            $("#overlay").fadeIn(300);
            $.ajax({
                url: getStudentListByClassSectionUrl,
                method: "post",
                data: formData,
                processData: false,
                dataType: 'json',
                contentType: false,
                success: function (response) {
                    console.log('ch', response);
                    if (response.code == 200) {
                        var dataSetNew = response.data;
                        if (dataSetNew.length > 0) {
                            $("#show_promotion_details").show();
                            bindStudents(dataSetNew);
                        } else {
                            toastr.error('No students available');
                            $("#show_promotion_details").hide();
                        }
                        $("#overlay").fadeOut(300);
                    } else {
                        $("#show_promotion_details").hide();
                        $("#overlay").fadeOut(300);
                        toastr.error(response.message);
                    }
                }, error: function (err) {
                    $("#show_promotion_details").hide();
                    $("#overlay").fadeOut(300);
                    toastr.error(err.responseJSON.data.error ? err.responseJSON.data.error : 'Something went wrong');
                }
            });
            setLocalStorageForadminpromotion(classObj);
        };
    });
    function setLocalStorageForadminpromotion(classObj) {

        var addpromotion = new Object();

        addpromotion.department_id = classObj.department_id;
        addpromotion.class_id = classObj.class_id;
        addpromotion.section_id = classObj.section_id;
        addpromotion.semester_id = classObj.semester_id;
        addpromotion.session_id = classObj.session_id;
        addpromotion.year = classObj.year;
        // here to attached to avoid localStorage other users to add
        addpromotion.branch_id = branchID;
        addpromotion.role_id = get_roll_id;
        addpromotion.user_id = ref_user_id;
        var addpromotionArr = [];
        addpromotionArr.push(addpromotion);
        if (get_roll_id == "2") {
            // Parent
            localStorage.removeItem("admin_promotion_details");
            localStorage.setItem('admin_promotion_details', JSON.stringify(addpromotionArr));
        }

        return true;
    }
    // rules validation
    $("#promoteStudentForm").validate({
        rules: {
            promote_year: "required",
            promote_class_id: "required",
            promote_semester_id: "required",
            promote_session_id: "required",
        }
    });
    // promote students
    $('#promoteStudentForm').on('submit', function (e) {
        $('.promotion_status').each(function () {
            if ($(this).is(':checked')) {
                var c = $(this).parent().parent().parent().find('.promoteSectionID');
                $(c).rules("add", {
                    required: true
                })
            } else if ($(this).is(':unchecked')) {
                var c = $(this).parent().parent().parent().find('.promoteSectionID');
                $(this).parent().parent().parent().find('.promoteSectionID').removeClass('error');
                $(c).rules("add", {
                    required: false
                })
            }
        });
        e.preventDefault();
        var form = this;
        // $('#saveClassRoomAttendance').prop('disabled', true);
        var promotionValid = $("#promoteStudentForm").valid();
        if (promotionValid === true) {
            $.ajax({
                url: $(form).attr('action'),
                method: $(form).attr('method'),
                data: new FormData(form),
                processData: false,
                dataType: 'json',
                contentType: false,
                success: function (response) {
                    console.log(response);
                    if (response.code == 200) {
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                }
            });
        }
    });

});

// function list mode
function bindStudents(dataSetNew) {
    // reset form
    $('#promoteStudentForm')[0].reset();

    listTable = $('#showStudentDetails').DataTable({
        processing: true,
        bDestroy: true,
        info: true,
        dom: 'lrt',
        "language": {

            "emptyTable": no_data_available,
            "infoFiltered": filter_from_total_entries,
            "zeroRecords": no_matching_records_found,
            "infoEmpty": showing_zero_entries,
            "info": showing_entries,
            "lengthMenu": show_entries,
            "search": datatable_search,
            "paginate": {
                "next": next,
                "previous": previous
            },
        },
        paging: false,
        searching: false,
        data: dataSetNew,
        columns: [
            {
                searchable: false,
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            },
            {
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            },
            {
                data: 'name'
            },
            {
                data: 'register_no'
            },
            {
                data: 'student_id'
            }
        ],
        columnDefs: [
            { "bSortable": false, "aTargets": [0, 1, 2, 3] },
            {
                "targets": 0,
                "className": "checked-area",
                "render": function (data, type, row, meta) {
                    var promote = '<div class="switchery-demo">' +
                        '<input type="hidden" name="promotion[' + meta.row + '][student_id]" value="' + row.student_id + '">' +
                        '<input type="hidden" name="promotion[' + meta.row + '][register_no]" value="' + row.register_no + '">' +
                        '<input type="hidden" name="promotion[' + meta.row + '][roll_no]" value="' + row.roll_no + '">' +
                        '<input type="checkbox" class="promotion_status" name="promotion[' + meta.row + '][promotion_status]"  data-plugin="switchery" data-color="#039cfd" />' +
                        '</div>';
                    return promote;
                }
            },
            {
                "targets": 1,
                "render": function (data, type, row, meta) {
                    return meta.row + 1;
                }
            },
            {
                "targets": 2,
                "className": "table-user",
                "render": function (data, type, row, meta) {
                    if (row.photo) {
                        var currentImg = studentImg + '/' + row.photo;
                    } else {
                        var currentImg = defaultImg;
                    }
                    var first_name = '<img src="' + currentImg + '" class="mr-2 rounded-circle" alt="No Image">' +
                        '<a href="javascript:void(0);" class="text-body font-weight-semibold">' + data + '</a>';
                    return first_name;
                }
            },
            {
                "targets": 3,
                "render": function (data, type, row, meta) {
                    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    var randomNumbers = Math.floor(Math.random() * 90000) + 10000;
                    var studentID = '9' + 'JSKL' + randomNumbers;
                    return studentID;
                    // var reg_no = "9ABCD12345";
                    // return reg_no;
                }
            },
            {
                "targets": 4,
                "render": function (data, type, row, meta) {
                    var drop = '<div class="form-group"><select class="form-control promoteSectionID" name="promotion[' + meta.row + '][promote_section_id]"><option value="">' + select_class + '</option></select></div>';
                    return drop;
                }
            }
        ]
    }).on('draw', function () {
    });
}
if (get_roll_id == "2") {
    // if localStorage
    if (typeof admin_promotion_storage !== 'undefined') {
        // variable is come
        if ((admin_promotion_storage)) {
            if (admin_promotion_storage) {
                var adminpromotionstorage = JSON.parse(admin_promotion_storage);
                if (adminpromotionstorage.length == 1) {
                    var department_id, class_id, section_id, semester_id, session_id, year, userBranchID, userRoleID, userID;
                    adminpromotionstorage.forEach(function (user) {
                        department_id = user.department_id;
                        class_id = user.class_id;
                        section_id = user.section_id;
                        semester_id = user.semester_id;
                        session_id = user.session_id;
                        year = user.year;
                        userBranchID = user.branch_id;
                        userRoleID = user.role_id;
                        userID = user.user_id;
                    });
                    if ((userBranchID == branchID) && (userRoleID == get_roll_id) && (userID == ref_user_id)) {
                        console.log("f");
                        console.log("f");
                        console.log(section_id);
                        console.log(year);
                        console.log("f");
                        var Selector = '#promotionFilter';
                        $(Selector).find('select[name="department_id"]').val(department_id);
                        if (department_id) {
                            $(Selector).find('select[name="class_id"]').empty();
                            $(Selector).find('select[name="class_id"]').append('<option value="">' + select_grade + '</option>');
                            $(Selector).find('select[name="section_id"]').empty();
                            $(Selector).find('select[name="section_id"]').append('<option value="">' + select_class + '</option>');
                            $.post(getGradeByDepartmentUrl, {
                                branch_id: branchID,
                                department_id: department_id
                            }, function (responses) {
                                console.log("sdasdsad");
                                console.log(responses)
                                if (responses.code == 200) {
                                    $.each(responses.data, function (key, val) {
                                        $(Selector).find('select[name="class_id"]').append('<option value="' + val.id + '">' + val.name + '</option>');
                                    });
                                    if (class_id != '') {
                                        $(Selector).find('select[name="class_id"]').val(class_id);
                                    }
                                    // after success
                                    $.post(teacherSectionUrl, {
                                        token: token,
                                        branch_id: branchID,
                                        teacher_id: ref_user_id,
                                        class_id: class_id
                                    }, function (res) {
                                        console.log("tecj dsfj");
                                        console.log(res)
                                        if (res.code == 200) {
                                            $.each(res.data, function (key, val) {
                                                var selected = (section_id == val.section_id) ? 'selected' : '';
                                                $("#sectionID").append('<option value="' + val.section_id + '" ' + selected + '>' + val.section_name + '</option>');
                                            });
                                        }
                                    }, 'json');
                                }
                            }, 'json');
                        }
                        $(Selector).find('select[name="semester_id"]').val(semester_id);
                        $(Selector).find('select[name="session_id"]').val(session_id);
                        $(Selector).find('select[name="year"]').val(year);
                        // $('select[name^="class_id"] option[value=' + class_id + ']').attr("selected", "selected");

                        // $("#section_id").empty();
                        // $("#section_id").append('<option value="">' + select_class + '</option>');

                        // $("#sectionID").empty();
                        // $("#sectionID").append('<option value="">' + select_class + '</option>');
                        // $.post(teacherSectionUrl, { token: token, branch_id: branchID, teacher_id: ref_user_id, class_id: class_id }, function (res) {
                        //     if (res.code == 200) {

                        //         $.each(res.data, function (key, val) {
                        //             var selected = (section_id == val.section_id) ? 'selected' : '';
                        //             $("#sectionID").append('<option value="' + val.section_id + '" ' + selected + '>' + val.section_name + '</option>');
                        //         });
                        //     }
                        // }, 'json');
                        // $('select[name^="semester_id"] option[value=' + semester_id + ']').attr("selected", "selected");
                        // $('select[name^="session_id"] option[value=' + session_id + ']').attr("selected", "selected");
                        // $('select[name^="year"] option[value=' + year + ']').attr("selected", "selected");


                    }
                }
            }
        }
    }
}