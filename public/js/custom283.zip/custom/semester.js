$(function () {
    $(document).ready(function () {

        $('#addSemesterModal').on('shown.bs.modal', function () {
            // $('.input-group.date').datepicker({
            //     format: "dd/mm/yyyy",
            //     startDate: "01-01-2015",
            //     endDate: "01-01-2020",
            //     todayBtn: "linked",
            //     autoclose: true,
            //     todayHighlight: true,
            //     container: '#addSemesterModal modal-body'
            // });
            $("#start_date").datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true,
                autoclose: true,
                yearRange: "-100:+50", // last hundred years
                container: '#addSemesterModal modal-body'
            });
            $("#end_date").datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true,
                autoclose: true,
                yearRange: "-100:+50", // last hundred years
                container: '#addSemesterModal modal-body'
            });
        });

        $('#editSemesterModal').on('shown.bs.modal', function () {
            $("#edit_start_date").datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true,
                autoclose: true,
                yearRange: "-100:+50", // last hundred years
                container: '#editSemesterModal modal-body'
            });
            $("#edit_end_date").datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true,
                autoclose: true,
                yearRange: "-100:+50", // last hundred years
                container: '#editSemesterModal modal-body'
            });
        });

    });

    $("#semesterForm").validate({
        rules: {
            name: "required",
            start_date: "required",
            end_date: "required",
            year: "required",
        }
    });
    $("#edit-semester-form").validate({
        rules: {
            name: "required",
            start_date: "required",
            end_date: "required",
            year: "required",
        }
    });
    // add semester
    $('#semesterForm').on('submit', function (e) {
        e.preventDefault();
        var semesterCheck = $("#semesterForm").valid();
        if (semesterCheck === true) {
            var form = this;

            $.ajax({
                url: $(form).attr('action'),
                method: $(form).attr('method'),
                data: new FormData(form),
                processData: false,
                dataType: 'json',
                contentType: false,
                success: function (data) {
                    // console.log("------")
                    console.log(data)
                    if (data.code == 200) {
                        $('#semester-table').DataTable().ajax.reload(null, false);
                        $('.addSemester').modal('hide');
                        $('.addSemester').find('form')[0].reset();
                        toastr.success(data.message);
                    } else {
                        toastr.error(data.message);
                    }
                }
            });
        }
    });

    // get all semester table
    $('#semester-table').DataTable({
        processing: true,
        info: true,
        // dom: 'lBfrtip',
        dom: "<'row'<'col-sm-2 col-md-2'l><'col-sm-4 col-md-4'B><'col-sm-6 col-md-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-6'i><'col-sm-6'p>>",
        "language": {

            "emptyTable": no_data_available,
            "infoFiltered": filter_from_total_entries,
            "zeroRecords": no_matching_records_found,
            "infoEmpty": showing_zero_entries,
            "info": showing_entries,
            "lengthMenu": show_entries,
            "search": datatable_search,
            "paginate": {
                "next": next,
                "previous": previous
            },
        },
        buttons: [
            {
                extend: 'csv',
                text: downloadcsv,
                extension: '.csv',
                charset: 'utf-8',
                bom: true,
                exportOptions: {
                    columns: 'th:not(:last-child)'
                }
            },
            {
                extend: 'pdf',
                text: downloadpdf,
                extension: '.pdf',
                charset: 'utf-8',
                bom: true,
                exportOptions: {
                    columns: 'th:not(:last-child)'
                },


                customize: function (doc) {
                    doc.pageMargins = [50, 50, 50, 50];
                    doc.defaultStyle.fontSize = 10;
                    doc.styles.tableHeader.fontSize = 12;
                    doc.styles.title.fontSize = 14;
                    // Remove spaces around page title
                    doc.content[0].text = doc.content[0].text.trim();
                    /*// Create a Header
                    doc['header']=(function(page, pages) {
                        return {
                            columns: [
                                
                                {
                                    // This is the right column
                                    bold: true,
                                    fontSize: 20,
                                    color: 'Blue',
                                    fillColor: '#fff',
                                    alignment: 'center',
                                    text: header_txt
                                }
                            ],
                            margin:  [50, 15,0,0]
                        }
                    });*/
                    // Create a footer

                    doc['footer'] = (function (page, pages) {
                        return {
                            columns: [
                                { alignment: 'left', text: [footer_txt], width: 400 },
                                {
                                    // This is the right column
                                    alignment: 'right',
                                    text: ['page ', { text: page.toString() }, ' of ', { text: pages.toString() }],
                                    width: 100

                                }
                            ],
                            margin: [50, 0, 0, 0]
                        }
                    });

                }

            }
        ],
        ajax: semesterList,
        "pageLength": 5,
        "aLengthMenu": [
            [5, 10, 25, 50, -1],
            [5, 10, 25, 50, "All"]
        ],
        columns: [
            {
                searchable: false,
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            },
            {
                data: 'name',
                name: 'name'
            },
            {
                data: 'start_date',
                name: 'start_date'
            },
            {
                data: 'end_date',
                name: 'end_date'
            },
            {
                data: 'academic_year',
                name: 'academic_year'
            },
            {
                data: 'actions',
                name: 'actions',
                orderable: false,
                searchable: false
            },
        ]
    }).on('draw', function () {
    });
    // get row
    $(document).on('click', '#editSemesterBtn', function () {
        var id = $(this).data('id');

        $('.editSemester').find('form')[0].reset();
        $.post(semesterDetails, { id: id }, function (data) {
            console.log("data")
            console.log(data);
            $('.editSemester').find('input[name="id"]').val(data.data.id);
            $('.editSemester').find('input[name="name"]').val(data.data.name);
            $('.editSemester').find('input[name="start_date"]').val(data.data.start_date);
            $('.editSemester').find('input[name="end_date"]').val(data.data.end_date);
            $('.editSemester').find('select[name="year"]').val(data.data.academic_session_id);
            $('.editSemester').modal('show');
        }, 'json');
        console.log(id);
    });
    // update Semester
    $('#edit-semester-form').on('submit', function (e) {
        e.preventDefault();
        var edt_semesterCheck = $("#edit-semester-form").valid();
        if (edt_semesterCheck === true) {

            var form = this;
            $.ajax({
                url: $(form).attr('action'),
                method: $(form).attr('method'),
                data: new FormData(form),
                processData: false,
                dataType: 'json',
                contentType: false,
                success: function (data) {
                    if (data.code == 0) {
                        $.each(data.error, function (prefix, val) {
                            $(form).find('span.' + prefix + '_error').text(val[0]);
                        });
                    } else {

                        if (data.code == 200) {
                            $('#semester-table').DataTable().ajax.reload(null, false);
                            $('.editSemester').modal('hide');
                            $('.editSemester').find('form')[0].reset();
                            toastr.success(data.message);
                        } else {
                            $('.editSemester').modal('hide');
                            $('.editSemester').find('form')[0].reset();
                            toastr.error(data.message);
                        }
                    }
                }
            });
        }
    });
    // delete SemesterDelete
    $(document).on('click', '#deleteSemesterBtn', function () {
        var id = $(this).data('id');
        var url = semesterDelete;
        swal.fire({
            title: deleteTitle + '?',
            html: deleteHtml,
            showCancelButton: true,
            showCloseButton: true,
            cancelButtonText: deletecancelButtonText,
            confirmButtonText: deleteconfirmButtonText,
            cancelButtonColor: '#d33',
            confirmButtonColor: '#556ee6',
            width: 400,
            allowOutsideClick: false
        }).then(function (result) {
            if (result.value) {
                $.post(url, {
                    id: id
                }, function (data) {
                    if (data.code == 200) {
                        $('#semester-table').DataTable().ajax.reload(null, false);
                        toastr.success(data.message);
                    } else {
                        toastr.error(data.message);
                    }
                }, 'json');
            }
        });
    });
});