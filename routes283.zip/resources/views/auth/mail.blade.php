<div style="width: 100%; display:block;">
<h2>Hi {{ $name }}</h2>
<p>
	<strong></strong><br>
	<h4>click here to reset your password :</h4>
           <a href="{{$link}}">{{ $link }}</a><br><br>
</p>
</div>