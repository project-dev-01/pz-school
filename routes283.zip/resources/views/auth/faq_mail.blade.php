<div style="width: 100%; display:block;">
<p>
	<strong></strong><br>
	<b>Email :</b>{{ $email }}
	<br>
	<b>{{ __('messages.name') }} :</b>{{ $name }}
	<br>
	<b>Role :</b>{{ $role_name }}
	<br>
	<b>Subject :</b>{{ $subject }}
	<br>
	<b>Rearks :</b>{{$remarks}}
           
</p>
</div>