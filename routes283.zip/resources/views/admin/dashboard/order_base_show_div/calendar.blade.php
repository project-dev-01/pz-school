<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3">
                        <div id="" class="m-t-20">
                            <br>
                        </div>

                    </div> <!-- end col-->

                    <div class="col-lg-12">
                        <!-- <div id="admin_calendor"></div> -->
                        <div id="new_calendor"></div>
                    </div> <!-- end col -->

                </div> <!-- end row -->
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div>
    <!-- end col-12 -->
</div>