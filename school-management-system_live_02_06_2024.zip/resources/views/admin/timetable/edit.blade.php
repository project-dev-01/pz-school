@extends('layouts.admin-layout')
@section('title','Edit Schedule')
@section('component_css')
<link href="{{ asset('libs/selectize/css/selectize.bootstrap3.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('libs/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
<!-- date picker -->
<link href="{{ asset('date-picker/jquery-ui.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('date-picker/style.css') }}" rel="stylesheet" type="text/css" />
<!-- toaster alert -->
<link rel="stylesheet" href="{{ asset('sweetalert2/sweetalert2.min.css') }}">
<link rel="stylesheet" href="{{ asset('toastr/toastr.min.css') }}">

@endsection
@section('content')
<style>
    .form-control:disabled,
    .form-control[readonly] {
        background-color: #eee;
        opacity: 1;
    }
</style>
<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <!--<ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Wizard</li>
                    </ol>-->
                </div>
                <h4 class="page-title">Grade Schedule</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->


    <div class="row" id="edit_timetable">
        <div class="col-xl-12 editTimetableForm">
            <div class="card">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <h4 class="nav-link"><i class="far fa-clock"></i>
                            @if($timetable)Grade {{ isset($details['class']['class_name']) ? $details['class']['class_name'] : "" }} (Class: {{ isset($details['section']['section_name']) ? $details['section']['section_name'] : "" }}) - {{ isset($details['day']) ? $details['day'] : "" }} - @endif Schedule Edit
                        </h4>
                    </li>
                </ul><br>
                <div class="card-body">
                    <form id="editTimetableForm" method="post" action="{{ route('admin.timetable.update') }}" enctype="multipart/form-data" autocomplete="off">
                        @csrf
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0 text-center" id="edit_timetable_table">
                                        @if($timetable)
                                        <thead>
                                            <tr>
                                                <th>{{ __('messages.break') }}</th>
                                                <th>{{ __('messages.subject') }}</th>
                                                <th>{{ __('messages.teacher') }}</th>
                                                <th>{{ __('messages.starting_time') }}</th>
                                                <th>{{ __('messages.ending_time') }}</th>
                                                <th>{{ __('messages.classroom') }}</th>
                                                <th>{{ __('messages.action') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody id="edit_timetable_body">

                                            @php $row = 0; @endphp
                                            @foreach($timetable as $table)
                                            @php
                                            $bulk = "";
                                            if($table['bulk_id']) {
                                            $bulk = "disabled";
                                            }
                                            @endphp
                                            <tr class="iadd">

                                                <input type="hidden" name="timetable[{{$row}}][id]" value="{{$table['id']}}" {{$bulk}}>
                                                <td>
                                                    <div class="checkbox-replace">
                                                        <label class="i-checks">
                                                            <input type="checkbox" name="timetable[{{$row}}][break]" {{$table['break'] == "1" ? 'checked' : ''}} {{$bulk}}><i></i>
                                                        </label>
                                                    </div>
                                                </td>
                                                @if($table['break'] == "1")
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <select class="form-control subject" name="timetable[{{$row}}][subject]" disabled hidden="hidden" {{$bulk}}>
                                                            <option value="">{{ __('messages.select_subject') }}</option>
                                                            @forelse($subject as $sub)
                                                            <option value="{{$sub['id']}}">{{$sub['name']}}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                        <input class="form-control break_type" type="text" name="timetable[{{$row}}][break_type]" value="{{$table['break_type']}}" {{$bulk}}></input>
                                                    </div>
                                                </td>
                                                @else
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <select class="form-control subject" name="timetable[{{$row}}][subject]" {{$bulk}}>
                                                            <option value="">{{ __('messages.select_subject') }}</option>
                                                            @forelse($subject as $sub)
                                                            <option value="{{$sub['id']}}" {{ $sub['id'] == $table['subject_id'] ? 'selected' : ''}}>{{$sub['name']}}</option>
                                                            
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                        <input class="form-control break_type" type="text" name="timetable[{{$row}}][break_type]" disabled hidden="hidden" {{$bulk}}></input>
                                                    </div>
                                                </td>
                                                @endif
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <select class="form-control teacher teacher select2-multiple-plus" data-toggle="select2" multiple="multiple" data-placeholder="Choose ..." name="timetable[{{$row}}][teacher][]" {{$bulk}}>
                                                            <option value="">{{ __('messages.select_teacher') }}</option>
                                                            @if($table['bulk_id'])
                                                            @php
                                                            $all = "";
                                                            foreach (explode(',', $table['teacher_id']) as $info) {
                                                            if($info == "0") {
                                                            $all = "Selected";
                                                            }
                                                            }
                                                            @endphp
                                                            <option value="0" {{ $all }}>{{ __('messages.all') }}</option>
                                                            @endif
                                                            @forelse($teacher as $teach)
                                                            @php
                                                            $selected = "";
                                                            @endphp
                                                            @if($table['teacher_id'])
                                                            @foreach(explode(',', $table['teacher_id']) as $info)
                                                            @if($teach['id'] == $info)
                                                            @php
                                                            $selected = "Selected";
                                                            @endphp
                                                            @endif
                                                            @endforeach
                                                            @endif
                                                            <option value="{{$teach['id']}}" {{ $selected }}>{{$teach['name']}}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                </td>
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <input class="form-control" type="time" name="timetable[{{$row}}][time_start]" value="{{$table['time_start']}}" {{$bulk}}>
                                                    </div>
                                                </td>
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <input class="form-control" type="time" name="timetable[{{$row}}][time_end]" value="{{$table['time_end']}}" {{$bulk}}>
                                                    </div>
                                                </td>
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <select class="form-control" name="timetable[{{$row}}][class_room]" {{$bulk}}>
                                                            <option value="">{{ __('messages.select_hall') }}</option>
                                                            @forelse($hall_list as $list)
                                                            <option value="{{$list['id']}}" {{ $list['id'] == $table['class_room'] ? 'selected' : ''}}>{{ $list['hall_no'] }}</option>
                                                            @empty
                                                            @endforelse
                                                        </select>
                                                    </div>
                                                    <!-- <div class="input-group"><input type="remarks" name="timetable[{{$row}}][class_room]" value="{{$table['class_room']}}" class="form-control"><button type="button" class=" btn btn-danger removeTR"><i class="fas fa-times"></i> </button></div> -->
                                                </td>
                                                <td width="20%">
                                                    <div class="form-group">
                                                        <button type="button" class=" btn btn-danger removeTR" {{$bulk}}><i class="fas fa-times"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            @php $row++; @endphp
                                            @endforeach

                                        </tbody>
                                        @else
                                        <tbody>
                                            <td>No Data Found </td>
                                        </tbody>
                                        @endif
                                    </table>

                                </div> <!-- end table-responsive-->
                            </div> <!-- end col-->
                        </div>
                        <br>
                        <!-- <button type="button" class="btn btn-soft-secondary waves-effect" id="addMore" >
					<i class="fas fa-plus-circle"></i> Add More				</button> -->
                        <!-- end row-->
                        @if($timetable)
                        <input type="hidden" id="form_class_id" name="class_id" value="{{ isset($details['class']['class_id']) ? $details['class']['class_id'] : '' }}">
                        <input type="hidden" id="form_section_id" name="section_id" value="{{ isset($details['section']['section_id']) ? $details['section']['section_id'] : '' }}">
                        <input type="hidden" id="form_semester_id" name="semester_id" value="{{ isset($details['semester']['semester_id']) ? $details['semester']['semester_id'] : '' }}">
                        <input type="hidden" id="form_session_id" name="session_id" value="{{ isset($details['session']['session_id']) ? $details['session']['session_id'] : '' }}">
                        <input type="hidden" id="form_day" name="day" value="{{isset($details['day']) ? $details['day'] : ''}}">
                        <div class="form-group text-right m-b-0">
                            <button class="btn btn-primary-bl waves-effect waves-light" type="Save">
                                Update
                            </button>
                            <a href="{{ route('admin.timetable') }}" class="btn btn-primary-bl waves-effect waves-light">
                                Back
                            </a>
                        </div>
                        @else
                        <div class="form-group text-right m-b-0">
                            <a href="{{ route('admin.timetable') }}" class="btn btn-primary-bl waves-effect waves-light">
                                Back
                            </a>
                        </div>
                        @endif
                    </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->

    </div>
    <!-- end row -->

</div> <!-- container -->

@endsection

@section('scripts')
<script src="{{ asset('libs/mohithg-switchery/switchery.min.js') }}"></script>
<script src="{{ asset('libs/select2/js/select2.min.js') }}"></script>
<script src="{{ asset('libs/selectize/js/standalone/selectize.min.js') }}"></script>
<!-- plugin js -->
<script src="{{ asset('libs/moment/min/moment.min.js') }}"></script>

<script src="{{ asset('sweetalert2/sweetalert2.min.js') }}"></script>
<script src="{{ asset('toastr/toastr.min.js') }}"></script>
<script src="{{ asset('date-picker/jquery-ui.js') }}"></script>
<script>
    toastr.options.preventDuplicates = true;
</script>
<script src="{{ asset('js/validation/validation.js') }}"></script>
<script>
    var sectionByClass = "{{ route('admin.section_by_class') }}";
    var subjectByClass = "{{ route('admin.timetable.subject') }}";
    var timetableList = "{{ route('admin.timetable') }}";
</script>
<script src="{{ asset('js/custom/timetable.js') }}"></script>
@endsection