<?php
// jskl all subjects
return [
  // primary 1,2 clasess
    'primary_language'=>'国語',
    'primary_math'=>'算数',
    'primary_life'=>'生活',
    'primary_music'=>'音楽',
    'primary_art'=>'図画工作',
    'primary_sport'=>'体育',
];
